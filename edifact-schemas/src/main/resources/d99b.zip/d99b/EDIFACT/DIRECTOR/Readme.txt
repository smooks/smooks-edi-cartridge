
                                                     
              UNITED NATIONS ECONOMIC COMMISSION FOR EUROPE
                             Trade Division
             Palais des Nations, CH-1211, Geneva, Switzerland
    Tel:+41 22/917 2773   Tlx: 412962 UNO CH   Fax:+41 22/917 0037
                     E-Mail: CEFACT(at)UNECE.ORG

           


                              UN/EDIFACT



                            D.99B DIRECTORY



                              1999-19-05


SOURCE: UN/EDIFACT WORKING GROUP (EWG)
STATUS: STANDARD
ACTION: FOR ACCEPTANCE BY CEFACT STEERING GROUP

The directory and other Trade Facilitation Information is also available 
on the UN/ECE WorldWideWeb site, page: "www.unece.org/trafix"

License agreement for the use of 
UN/EDIFACT directories: read file licenagr.txt

------------------------------------------------------------------------

For the interactive directory, it must be noted that the syntax 
and associated messages are based on document TRADE/WP.4/R.1157/Add.2 
of 28 July 1995.


USAGE OF THE DISKETTE

- The file audit99b.txt contains the Directory Audit Team Statement for this
directory. 

- The file content.txt is the table of contents of the UN/EDIFACT Standard
 Directory.


- The files xxx.zip are compressed versions in ASCII (code page 
437 United States) of the UN Trade Data Interchange Directory using
the compression program PKZIP. The contents of Directory files is described 
in the file content.txt.

To get the decompressed version of the Directory, use the program pkunzip.exe 
stored on the diskette.

Type the commands:

 PKUNZIP [x:]xxx.ZIP       [y:][path]
 
  
 where
  x:      is the drive on which the diskette is stored
  y:      is the drive on which the decompressed version will be stored.
  path    specifies the path to the directory where the decompressed
          version will be stored.


-------------------------------------------------------------------
   PKUNZIP is a product of PKware:
      
      PKware, Inc.
      7545 North Port Washington Road
      Glendale, WI 53217-3422
      Fax: 414 352 3815

 PKUNZIP(tm) FAST! Extract Utility
 Copyright 1989 PKWARE Inc. All Rights Reserved

PKWARE, INC. HAS DONATED THE USE OF THE PKUNZIP(tm) DATA EXTRACTION
         UTILITY TO UN/ECE FOR USE WITH UNTDED AND UNTDID.

------------------------------------------------------------------
